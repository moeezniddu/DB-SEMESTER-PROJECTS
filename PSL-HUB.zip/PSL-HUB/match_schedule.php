<!DOCTYPE html>
<html>
<head>
    <title>Match Schedule</title>
    <style>
        /* Include your CSS styles here */
        /* Navigation bar styles */
        nav {
            background-color: #333;
            overflow: hidden;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav .logo {
            padding: 10px 20px;
        }

        nav .logo img {
            max-height: 40px;
        }

        nav a {
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        nav a.active {
            background-color: #4CAF50;
            color: white;
        }
        /* Additional styles for the match schedule table */
        .match-schedule-table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            color: #070707;
            background-color: rgb(152, 198, 84);
            margin-bottom: 30px;
        }
        
        .match-schedule-table th, .match-schedule-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .match-schedule-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            font-size: 14px;
        }
        
        .match-schedule-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .match-schedule-table tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo">
            <a href="#"><img src="psl_logo.png" alt="Logo"></a>
        </div>
        <div class="nav-links">
            <a href="index.html">Home</a>
            <a href="searchplayers.html">Players</a>
            <a href="#" class="active">Match Schedule</a>
            <a href="pointstable.php">Points Table</a>
            <a href="Teams.html">Teams</a>
            <a href="login.html">Login as Administrator</a>
        </div>
    </nav>
    
    <h2>Match Schedule</h2>

    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "pslhub";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch match schedule data
    $sql = "SELECT matches.match_id AS match_number,
                   team1.team_name AS team_1,
                   team2.team_name AS team_2,
                   CASE WHEN matches.winning_team IS NOT NULL THEN winning_team.team_name ELSE 'Not played yet' END AS winning_team
            FROM matches
            INNER JOIN teams AS team1 ON matches.team1_id = team1.team_id
            INNER JOIN teams AS team2 ON matches.team2_id = team2.team_id
            LEFT JOIN teams AS winning_team ON matches.winning_team = winning_team.team_id
            ORDER BY matches.match_id ASC";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        echo '<table class="match-schedule-table">';
        echo '<tr><th>Match Number</th><th>Team 1</th><th>Team 2</th><th>Winning Team</th></tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["match_number"] . '</td>';
            echo '<td>' . $row["team_1"] . '</td>';
            echo '<td>' . $row["team_2"] . '</td>';
            echo '<td>' . $row["winning_team"] . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo "0 results";
    }

    $conn->close();
    ?>

</body>
</html>
